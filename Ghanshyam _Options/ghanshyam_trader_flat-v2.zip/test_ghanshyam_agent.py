"""
Unit Test Suite for Ghanshyam Trader System
"""

import unittest
from datetime import datetime, date, time, timedelta

from config import IndexConfig
from models import Candle, Direction, LDCHLLevels, OptionType, StrategyId, TradeSignal
from risk import RiskEngine
from strikes import OptionStrikeSelector
from strategies import StrategyRegistry
from broker import PaperTradingBroker
from agent import IndexTradingAgent
from backtester import BacktestEngine
from realtime_runner import MultiAssetTradingManager


class TestRiskEngine(unittest.TestCase):
    def setUp(self):
        self.risk = RiskEngine(
            total_capital=1000000.0,
            max_capital_per_trade_pct=0.25,
            max_daily_drawdown_pct=0.03,
            max_daily_trades=3,
            max_consecutive_losses=2,
            profit_lock_pct=0.80
        )

    def test_capital_tranche_and_lot_sizing(self):
        qty_trend = self.risk.calculate_lot_size(option_premium=250.0, lot_size=15, is_trend_aligned=True)
        self.assertEqual(qty_trend, 66 * 15)

        qty_counter = self.risk.calculate_lot_size(option_premium=250.0, lot_size=15, is_trend_aligned=False)
        self.assertEqual(qty_counter, 33 * 15)

    def test_consecutive_losses_lockout(self):
        can_trade, _ = self.risk.can_take_trade()
        self.assertTrue(can_trade)

        self.risk.record_trade_completion(-5000.0)
        self.risk.record_trade_completion(-4000.0)
        can_trade, reason = self.risk.can_take_trade()
        self.assertFalse(can_trade)
        self.assertTrue(self.risk.is_locked_out)
        self.assertIn("consecutive losses", reason)


class TestMultiAssetManager(unittest.TestCase):
    def setUp(self):
        self.manager = MultiAssetTradingManager(total_capital=500000.0)

    def test_multi_index_routing(self):
        self.manager.set_levels("BANKNIFTY", pdh=52000, pdl=51000, pdc=51500, trend=Direction.BULLISH)
        self.manager.set_levels("NIFTY", pdh=24600, pdl=24300, pdc=24450, trend=Direction.BULLISH)

        c1 = Candle(datetime(2026, 10, 19, 9, 15), 51500, 51580, 51480, 51560)
        c2 = Candle(datetime(2026, 10, 19, 9, 20), 51560, 51620, 51550, 51610)

        self.manager.on_candle_event("NSE:NIFTYBANK-INDEX", c1, spot_ltp=51560)
        sig = self.manager.on_candle_event("NSE:NIFTYBANK-INDEX", c2, spot_ltp=51610)

        self.assertIsNotNone(sig)
        self.assertEqual(sig.strategy, StrategyId.STRATEGY_920_AM)


if __name__ == "__main__":
    unittest.main()
