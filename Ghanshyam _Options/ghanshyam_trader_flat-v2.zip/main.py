"""
Main CLI Entrypoint for Ghanshyam Trader (Backtesting & Realtime Session Modes)
"""

import argparse
import logging
import sys
from datetime import datetime, date, time, timedelta
from typing import Dict, List, Optional, Tuple

from config import IndexConfig
from models import Candle, Direction, LDCHLLevels
from backtester import BacktestEngine
from realtime_runner import MultiAssetTradingManager, RealtimeSessionRunner

logger = logging.getLogger("GhanshyamTradingSystem")


def generate_mock_multiday_data(num_days: int = 5) -> Dict[date, Dict[str, List[Candle]]]:
    """Generates synthetic multi-day 5-minute candle data for backtesting demonstration."""
    data = {}
    base_date = date(2026, 10, 12)

    for d in range(num_days):
        current_date = base_date + timedelta(days=d)
        bn_candles = []
        nf_candles = []

        bn_p = 51500.0 + (d * 100.0)
        nf_p = 24400.0 + (d * 50.0)

        start_dt = datetime.combine(current_date, time(9, 15))

        for b in range(75):
            bar_ts = start_dt + timedelta(minutes=5 * b)

            bn_high = bn_p + (20.0 if b % 2 == 0 else 80.0)
            bn_low = bn_p - (15.0 if b % 3 == 0 else 50.0)
            bn_close = bn_high - 10.0 if b % 2 == 0 else bn_low + 10.0
            bn_candles.append(Candle(bar_ts, bn_p, bn_high, bn_low, bn_close, volume=1000))
            bn_p = bn_close

            nf_high = nf_p + (10.0 if b % 2 == 0 else 35.0)
            nf_low = nf_p - (8.0 if b % 3 == 0 else 25.0)
            nf_close = nf_high - 5.0 if b % 2 == 0 else nf_low + 5.0
            nf_candles.append(Candle(bar_ts, nf_p, nf_high, nf_low, nf_close, volume=2000))
            nf_p = nf_close

        data[current_date] = {
            "BANKNIFTY": bn_candles,
            "NIFTY": nf_candles
        }

    return data


def fetch_fyers_multiday_data(
    fyers_client=None,
    symbols: Optional[Dict[str, str]] = None,
    range_from: Optional[str] = None,
    range_to: Optional[str] = None,
    num_days: int = 5,
    resolution: str = "5"
) -> Tuple[Dict[date, Dict[str, List[Candle]]], Dict[date, Dict[str, LDCHLLevels]]]:
    """
    Fetches historical 5-minute candle data directly from Fyers API v3 using fyers_client.history().

    Parameters:
    -----------
    fyers_client : Authenticated fyersModel.FyersModel client instance
    symbols      : Dict mapping internal benchmark code to Fyers symbol string
    range_from   : Start date string 'YYYY-MM-DD'
    range_to     : End date string 'YYYY-MM-DD'
    num_days     : Lookback calendar days if range_from is omitted
    resolution   : Candle timeframe (default: '5' for 5-minute candles)

    Returns:
    --------
    Tuple of:
      1. multiday_candles : Dict[date, Dict['BANKNIFTY'|'NIFTY', List[Candle]]]
      2. ldc_by_date      : Dict[date, Dict['BANKNIFTY'|'NIFTY', LDCHLLevels]]
    """
    if symbols is None:
        symbols = {
            "BANKNIFTY": "NSE:NIFTYBANK-INDEX",
            "NIFTY": "NSE:NIFTY50-INDEX"
        }

    if not range_to:
        range_to = datetime.now().strftime("%Y-%m-%d")

    if not range_from:
        lookback = max(num_days * 2, 10)
        range_from = (datetime.now() - timedelta(days=lookback)).strftime("%Y-%m-%d")

    multiday_candles: Dict[date, Dict[str, List[Candle]]] = {}

    if fyers_client and hasattr(fyers_client, "history"):
        print(f"\n[Fyers API] Fetching historical candle data via fyers_client.history() [{range_from} to {range_to}]...")
        for code, sym in symbols.items():
            req_data = {
                "symbol": sym,
                "resolution": resolution,
                "date_format": "1",  # YYYY-MM-DD format
                "range_from": range_from,
                "range_to": range_to,
                "cont_flag": "1"
            }
            try:
                res = fyers_client.history(data=req_data)
                if res and res.get("s") == "ok":
                    raw_candles = res.get("candles", [])
                    print(f"[Fyers API] Successfully fetched {len(raw_candles)} candles for {code} ({sym}).")
                    for c in raw_candles:
                        # Fyers candle structure: [epoch_timestamp, open, high, low, close, volume]
                        dt = datetime.fromtimestamp(c[0])
                        c_date = dt.date()
                        candle_obj = Candle(
                            timestamp=dt,
                            open=float(c[1]),
                            high=float(c[2]),
                            low=float(c[3]),
                            close=float(c[4]),
                            volume=float(c[5]) if len(c) > 5 else 0.0
                        )
                        if c_date not in multiday_candles:
                            multiday_candles[c_date] = {}
                        if code not in multiday_candles[c_date]:
                            multiday_candles[c_date][code] = []
                        multiday_candles[c_date][code].append(candle_obj)
                else:
                    logger.warning(f"[Fyers API] History request for {code} status: {res}")
            except Exception as e:
                logger.error(f"[Fyers API] Failed to fetch history for {code}: {e}")

    if not multiday_candles:
        print("[Info] fyers_client not provided or returned no candles. Using fallback demonstration dataset.")
        multiday_candles = generate_mock_multiday_data(num_days=num_days)

    # Calculate dynamic LDCHL levels from actual previous day candles
    sorted_dates = sorted(multiday_candles.keys())
    ldc_by_date: Dict[date, Dict[str, LDCHLLevels]] = {}

    for idx, current_date in enumerate(sorted_dates):
        ldc_by_date[current_date] = {}
        if idx > 0:
            prev_date = sorted_dates[idx - 1]
            for code in multiday_candles[current_date].keys():
                prev_candles = multiday_candles[prev_date].get(code, [])
                if prev_candles:
                    pdh = max(c.high for c in prev_candles)
                    pdl = min(c.low for c in prev_candles)
                    pdc = prev_candles[-1].close
                    trend = Direction.BULLISH if pdc >= prev_candles[0].open else Direction.BEARISH
                    ldc_by_date[current_date][code] = LDCHLLevels(pdh=pdh, pdl=pdl, pdc=pdc, daily_trend=trend)

        for code in multiday_candles[current_date].keys():
            if code not in ldc_by_date[current_date]:
                day_candles = multiday_candles[current_date][code]
                first_c = day_candles[0]
                ldc_by_date[current_date][code] = LDCHLLevels(
                    pdh=first_c.high + 100.0,
                    pdl=first_c.low - 100.0,
                    pdc=first_c.open,
                    daily_trend=Direction.BULLISH
                )

    return multiday_candles, ldc_by_date


def run_backtest_mode(
    capital: float,
    expiry: str,
    fyers_client=None,
    range_from: Optional[str] = None,
    range_to: Optional[str] = None,
    num_days: int = 5
):
    """Executes multi-day historical backtest and prints date-by-date PnL table."""
    print("\n" + "=" * 80)
    print("        RUNNING HISTORICAL MULTI-DAY BACKTESTING ENGINE")
    print("=" * 80)

    engine = BacktestEngine(initial_capital=capital, banknifty_expiry=expiry, nifty_expiry=expiry)

    # Ingest historical candle data via Fyers API if connected, or fallback
    multiday_data, ldc_by_date = fetch_fyers_multiday_data(
        fyers_client=fyers_client,
        range_from=range_from,
        range_to=range_to,
        num_days=num_days
    )

    result = engine.run_backtest(multiday_data, daily_ldc_by_date=ldc_by_date)
    result.print_daily_pnl_table()


def run_realtime_mode(
    capital: float,
    expiry: str,
    is_live: bool = False,
    fyers_client=None,
    range_from: Optional[str] = None,
    range_to: Optional[str] = None
):
    """Executes live/paper trading session from 09:15 to 15:30 IST."""
    manager = MultiAssetTradingManager(
        total_capital=capital,
        fyers_client=fyers_client,
        is_paper=not is_live,
        banknifty_expiry=expiry,
        nifty_expiry=expiry
    )

    runner = RealtimeSessionRunner(manager)

    mock_data, ldc_data = fetch_fyers_multiday_data(
        fyers_client=fyers_client,
        range_from=range_from,
        range_to=range_to,
        num_days=1
    )

    today_dt = sorted(mock_data.keys())[-1]

    if today_dt in ldc_data:
        if "BANKNIFTY" in ldc_data[today_dt]:
            l = ldc_data[today_dt]["BANKNIFTY"]
            manager.set_levels("BANKNIFTY", pdh=l.pdh, pdl=l.pdl, pdc=l.pdc, trend=l.daily_trend)
        if "NIFTY" in ldc_data[today_dt]:
            l = ldc_data[today_dt]["NIFTY"]
            manager.set_levels("NIFTY", pdh=l.pdh, pdl=l.pdl, pdc=l.pdc, trend=l.daily_trend)

    bn_candles = mock_data[today_dt].get("BANKNIFTY", [])
    nf_candles = mock_data[today_dt].get("NIFTY", [])

    runner.run_simulated_session(bn_candles, nf_candles)


def main():
    parser = argparse.ArgumentParser(description="Ghanshyam Tech Multi-Asset Options Trading Agent v3.1")
    parser.add_argument("--mode", type=str, choices=["backtest", "realtime", "live"], default="backtest",
                        help="Execution mode: 'backtest' (multi-day historical test), 'realtime' (paper simulation), or 'live' (Fyers API)")
    parser.add_argument("--capital", type=float, default=500000.0, help="Initial trading capital in INR (default: 500000)")
    parser.add_argument("--expiry", type=str, default="26OCT", help="Option expiry string e.g. '26OCT'")
    parser.add_argument("--client-id", type=str, default=None, help="Fyers API Client ID (required for live mode or Fyers backtesting)")
    parser.add_argument("--access-token", type=str, default=None, help="Fyers API Access Token (required for live mode or Fyers backtesting)")
    parser.add_argument("--range-from", type=str, default=None, help="Backtest start date 'YYYY-MM-DD'")
    parser.add_argument("--range-to", type=str, default=None, help="Backtest end date 'YYYY-MM-DD'")
    parser.add_argument("--num-days", type=int, default=5, help="Number of backtest days if range-from omitted (default: 5)")

    args = parser.parse_args()

    fyers_client = None
    if args.client_id and args.access_token:
        try:
            from fyers_apiv3 import fyersModel
            fyers_client = fyersModel.FyersModel(client_id=args.client_id, token=args.access_token, is_async=False, log_path="")
            print("Successfully authenticated Fyers API client.")
        except ImportError:
            print("fyers_apiv3 library not installed. Continuing without live Fyers API connection.")
    elif args.mode == "live":
        print("Error: --client-id and --access-token are required for live mode.")
        sys.exit(1)

    if args.mode == "backtest":
        run_backtest_mode(
            capital=args.capital,
            expiry=args.expiry,
            fyers_client=fyers_client,
            range_from=args.range_from,
            range_to=args.range_to,
            num_days=args.num_days
        )
    else:
        run_realtime_mode(
            capital=args.capital,
            expiry=args.expiry,
            is_live=(args.mode == "live"),
            fyers_client=fyers_client,
            range_from=args.range_from,
            range_to=args.range_to
        )


if __name__ == "__main__":
    main()
