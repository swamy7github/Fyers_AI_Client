"""
test_options_engine.py
--------------------------
Tests for options_engine.py's DUAL-SOURCE design: PRICE/VWAP signal from the
NIFTY index, VOLUME signal from the NIFTY future, execution on a single OTM
option contract (see options_engine.py's module docstring).

Covers: the F&O symbol-master loader/column validation, OTM strike/expiry
resolution (including the "fewer OTM strikes listed than requested" fallback),
the opening-range fetch, NiftyOptionsEngine's entry/exit arithmetic fed
directly via feed_candles() (hand-verified VWAP numbers, reusing the exact
warm-up pattern test_signal_engine.py already proved out for equities), and
run_nifty_options_engine()'s CE-on-LONG/PE-on-SHORT wiring.

Everything here is a locally-built pandas DataFrame or a tiny Fake data
service - no real Fyers symbol master file or network call is involved.

Run with:
    python test_options_engine.py
"""

from __future__ import annotations

import os
import shutil
import tempfile
import unittest

import pandas as pd

import config
import options_engine
from options_engine import NiftyOptionsEngine
from trade_direction import TradeDirection

_MASTER_COLUMNS = config.NIFTY_FO_MASTER_COLUMNS  # {logical: actual column name}


def _master_row(option_type, strike, expiry, lot_size=75, symbol=None):
    symbol = symbol or f"NSE:NIFTY25O14{int(strike)}{option_type}"
    return {
        _MASTER_COLUMNS["underlying"]: "NIFTY",
        _MASTER_COLUMNS["option_type"]: option_type,
        _MASTER_COLUMNS["expiry"]: expiry,
        _MASTER_COLUMNS["strike"]: strike,
        _MASTER_COLUMNS["trading_symbol"]: symbol,
        _MASTER_COLUMNS["lot_size"]: lot_size,
    }


def _sample_master() -> pd.DataFrame:
    """Two expiries, several strikes each, both CE and PE - enough to exercise
    "nearest expiry" AND "Nth OTM strike within that expiry" selection."""
    rows = []
    for expiry in ("2026-10-14", "2026-10-21"):
        for strike in (24800, 24850, 24900, 24950, 25000, 25050, 25100):
            for opt_type in ("CE", "PE"):
                rows.append(_master_row(opt_type, strike, expiry))
    return pd.DataFrame(rows)


class FakeQuoteDataService:
    """Implements only get_quotes - enough for resolve_otm_option_symbol/_fetch_nifty_spot
    and NiftyOptionsEngine's option-price fetch. `spot` feeds NIFTY_INDEX_SYMBOL lookups;
    `option_prices` (a dict or a single float) feeds any other symbol."""

    def __init__(self, spot: float | None, option_prices=None):
        self._spot = spot
        self._option_prices = option_prices if isinstance(option_prices, dict) else {}
        self._default_option_price = option_prices if isinstance(option_prices, (int, float)) else None

    def get_quotes(self, symbols):
        symbol = symbols[0]
        if symbol == config.NIFTY_INDEX_SYMBOL:
            if self._spot is None:
                return {"d": []}
            return {"d": [{"n": symbol, "v": {"lp": self._spot}}]}
        price = self._option_prices.get(symbol, self._default_option_price)
        if price is None:
            return {"d": []}
        return {"d": [{"n": symbol, "v": {"lp": price}}]}


class FakeCandleDataService:
    """Implements only get_5min_candle - enough for fetch_index_opening_range /
    NiftyOptionsEngine.check_all(). `candles_by_symbol` maps symbol -> the ONE candle
    (a list) to return for ANY window requested for that symbol."""

    def __init__(self, candles_by_symbol: dict[str, list]):
        self._candles_by_symbol = candles_by_symbol
        self.calls = []

    def get_5min_candle(self, symbol, date_str, from_epoch, to_epoch):
        self.calls.append((symbol, date_str, from_epoch, to_epoch))
        candle = self._candles_by_symbol.get(symbol)
        return [candle] if candle else []


class FakeFullDataService(FakeQuoteDataService, FakeCandleDataService):
    def __init__(self, spot, candles_by_symbol, option_prices=None):
        FakeQuoteDataService.__init__(self, spot, option_prices)
        FakeCandleDataService.__init__(self, candles_by_symbol)


# ----------------------------------------------------------------------------
# Symbol master
# ----------------------------------------------------------------------------
class TestLoadFoSymbolMaster(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp_dir, ignore_errors=True)

    def test_missing_file_returns_empty_dataframe_without_raising(self):
        df = options_engine.load_fo_symbol_master(os.path.join(self.tmp_dir, "does_not_exist.csv"))
        self.assertTrue(df.empty)

    def test_missing_expected_column_returns_empty_dataframe(self):
        path = os.path.join(self.tmp_dir, "master.csv")
        pd.DataFrame([{"some_other_column": 1}]).to_csv(path, index=False)
        df = options_engine.load_fo_symbol_master(path)
        self.assertTrue(df.empty)

    def test_well_formed_file_loads_successfully(self):
        path = os.path.join(self.tmp_dir, "master.csv")
        _sample_master().to_csv(path, index=False)
        df = options_engine.load_fo_symbol_master(path)
        self.assertFalse(df.empty)
        self.assertEqual(len(df), 28)  # 2 expiries x 7 strikes x 2 option types


# ----------------------------------------------------------------------------
# OTM strike resolution
# ----------------------------------------------------------------------------
class TestResolveOtmOptionSymbol(unittest.TestCase):
    def test_ce_picks_the_first_strike_above_spot_by_default(self):
        master = _sample_master()
        # Spot 24,910 - strikes above spot are 24950, 25000, 25050, 25100 - nearest (1-away) is 24950.
        data_service = FakeQuoteDataService(spot=24_910.0)
        symbol, lot_size = options_engine.resolve_otm_option_symbol(data_service, "CE", symbol_master=master)
        self.assertIn("24950", symbol)
        self.assertIn("CE", symbol)
        self.assertEqual(lot_size, 75)

    def test_pe_picks_the_first_strike_below_spot_by_default(self):
        master = _sample_master()
        # Spot 24,910 - strikes below spot are 24900, 24850, 24800 - nearest (1-away) is 24900.
        data_service = FakeQuoteDataService(spot=24_910.0)
        symbol, _ = options_engine.resolve_otm_option_symbol(data_service, "PE", symbol_master=master)
        self.assertIn("24900", symbol)
        self.assertIn("PE", symbol)

    def test_strikes_away_parameter_picks_further_otm(self):
        master = _sample_master()
        data_service = FakeQuoteDataService(spot=24_910.0)
        # 2-away CE: strikes above spot ascending are 24950(1st), 25000(2nd).
        symbol, _ = options_engine.resolve_otm_option_symbol(data_service, "CE", symbol_master=master,
                                                               strikes_away=2)
        self.assertIn("25000", symbol)

    def test_falls_back_to_farthest_available_when_fewer_strikes_than_requested(self):
        master = _sample_master()
        data_service = FakeQuoteDataService(spot=24_910.0)
        # Only 4 strikes exist above spot (24950/25000/25050/25100) - asking for the 10th
        # should fall back to the farthest (25100), not crash or return None.
        symbol, _ = options_engine.resolve_otm_option_symbol(data_service, "CE", symbol_master=master,
                                                               strikes_away=10)
        self.assertIn("25100", symbol)

    def test_uses_nearest_expiry_not_a_later_one(self):
        master = _sample_master()
        data_service = FakeQuoteDataService(spot=24_910.0)
        symbol, _ = options_engine.resolve_otm_option_symbol(data_service, "PE", symbol_master=master)
        self.assertIn("24900", symbol)

    def test_empty_master_returns_none(self):
        data_service = FakeQuoteDataService(spot=24_910.0)
        result = options_engine.resolve_otm_option_symbol(data_service, "CE", symbol_master=pd.DataFrame())
        self.assertIsNone(result)

    def test_no_matching_option_type_returns_none(self):
        master = _sample_master()
        master = master[master[_MASTER_COLUMNS["option_type"]] == "CE"]  # drop all PE rows
        data_service = FakeQuoteDataService(spot=24_910.0)
        result = options_engine.resolve_otm_option_symbol(data_service, "PE", symbol_master=master)
        self.assertIsNone(result)

    def test_unresolvable_spot_returns_none(self):
        master = _sample_master()
        data_service = FakeQuoteDataService(spot=None)  # simulates a quotes call returning nothing
        result = options_engine.resolve_otm_option_symbol(data_service, "CE", symbol_master=master)
        self.assertIsNone(result)

    def test_strikes_away_below_one_is_treated_as_one(self):
        master = _sample_master()
        data_service = FakeQuoteDataService(spot=24_910.0)
        symbol, _ = options_engine.resolve_otm_option_symbol(data_service, "CE", symbol_master=master,
                                                               strikes_away=0)
        self.assertIn("24950", symbol)


# ----------------------------------------------------------------------------
# Index opening-range fetch
# ----------------------------------------------------------------------------
class TestFetchIndexOpeningRange(unittest.TestCase):
    def test_returns_high_low_from_the_opening_range_candle(self):
        candle = [1234567890, 24900.0, 24950.0, 24880.0, 24920.0, 0]  # index volume often 0 - irrelevant here
        data_service = FakeCandleDataService({config.NIFTY_INDEX_SYMBOL: candle})
        result = options_engine.fetch_index_opening_range(data_service)
        self.assertEqual(result, (24950.0, 24880.0))

    def test_no_candle_available_returns_none(self):
        data_service = FakeCandleDataService({})
        result = options_engine.fetch_index_opening_range(data_service)
        self.assertIsNone(result)


# ----------------------------------------------------------------------------
# NiftyOptionsEngine entry/exit arithmetic (fed directly via feed_candles)
# ----------------------------------------------------------------------------
class TestNiftyOptionsEngineLongBias(unittest.TestCase):
    """Reuses test_signal_engine.py's exact proven warm-up/entry candle numbers (base_price=95.0
    ramping by 0.05 over 20 candles, or_high=100.0, entry candles 100.5->101.0 then 101.0->101.8
    with volumes 2000/2200) - here fed as the INDEX's candles, with the FUTURES candles
    supplying the matching volumes instead of the index's own."""

    def setUp(self):
        self.orig_dry_run = config.DRY_RUN
        config.DRY_RUN = True
        data_service = FakeQuoteDataService(spot=None, option_prices=150.0)
        self.engine = NiftyOptionsEngine(data_service, option_symbol="NSE:NIFTY25O1425000CE",
                                          option_lot_size=75, bias_direction=TradeDirection.LONG,
                                          index_or_high=100.0, index_or_low=100.0,
                                          capital_allocated=200_000.0)

    def tearDown(self):
        config.DRY_RUN = self.orig_dry_run

    def _warmup(self, count=20, base_price=95.0, volume=1000):
        for i in range(count):
            c = base_price + i * 0.05
            index_candle = [1700000000 + i, c, c + 0.2, c - 0.2, c, 1000]
            futures_candle = [1700000000 + i, c, c + 0.2, c - 0.2, c, volume]
            self.engine.feed_candles(index_candle, futures_candle, f"09:{20 + i}:00", is_backfill=False)

    def test_entry_fires_on_index_breakout_confirmed_by_futures_volume(self):
        self._warmup()
        self.engine.feed_candles([1, 100.5, 101.5, 100.2, 101.0, 999],
                                  [1, 100.5, 101.5, 100.2, 101.0, 2000], "09:45:00", is_backfill=False)
        self.engine.feed_candles([2, 101.0, 102.0, 100.8, 101.8, 999],
                                  [2, 101.0, 102.0, 100.8, 101.8, 2200], "09:50:00", is_backfill=False)

        self.assertTrue(self.engine.option.is_open)
        self.assertEqual(self.engine.option.entry_price, 150.0)  # the OPTION's own premium, not the index close
        expected_qty = int(200_000.0 // (150.0 * 75)) * 75
        self.assertEqual(self.engine.option.qty, expected_qty)
        self.assertEqual(self.engine.trade_book.trades[0]["symbol"], "NSE:NIFTY25O1425000CE")

    def test_index_breakout_without_futures_volume_confirmation_does_not_enter(self):
        self._warmup()
        # Index candles qualify on price/VWAP, but futures volume stays AT/below its own MA (~1000).
        self.engine.feed_candles([1, 100.5, 101.5, 100.2, 101.0, 999],
                                  [1, 100.5, 101.5, 100.2, 101.0, 500], "09:45:00", is_backfill=False)
        self.engine.feed_candles([2, 101.0, 102.0, 100.8, 101.8, 999],
                                  [2, 101.0, 102.0, 100.8, 101.8, 500], "09:50:00", is_backfill=False)
        self.assertFalse(self.engine.option.is_open)

    def test_only_one_qualifying_pair_does_not_yet_enter(self):
        self._warmup()
        self.engine.feed_candles([1, 100.5, 101.5, 100.2, 101.0, 999],
                                  [1, 100.5, 101.5, 100.2, 101.0, 2000], "09:45:00", is_backfill=False)
        self.assertFalse(self.engine.option.is_open)

    def test_exit_fires_on_index_closing_below_vwap_confirmed_by_futures_volume(self):
        self._warmup()
        self.engine.feed_candles([1, 100.5, 101.5, 100.2, 101.0, 999],
                                  [1, 100.5, 101.5, 100.2, 101.0, 2000], "09:45:00", is_backfill=False)
        self.engine.feed_candles([2, 101.0, 102.0, 100.8, 101.8, 999],
                                  [2, 101.0, 102.0, 100.8, 101.8, 2200], "09:50:00", is_backfill=False)
        self.assertTrue(self.engine.option.is_open)

        # Two consecutive index candles closing well below the running VWAP, futures volume
        # above its own (slowly-rising) 20-period MA on both.
        self.engine.feed_candles([3, 95.0, 95.2, 90.0, 91.0, 999],
                                  [3, 95.0, 95.2, 90.0, 91.0, 2500], "09:55:00", is_backfill=False)
        self.engine.feed_candles([4, 91.0, 91.2, 85.0, 86.0, 999],
                                  [4, 91.0, 91.2, 85.0, 86.0, 2700], "10:00:00", is_backfill=False)

        self.assertFalse(self.engine.option.is_open)
        trade = self.engine.trade_book.trades[0]
        self.assertEqual(trade["exit_price"], 150.0)  # FakeQuoteDataService returns a flat 150.0 always
        self.assertIsNotNone(trade["exit_time"])

    def test_entry_skipped_when_capital_cant_afford_one_lot(self):
        self.engine.option.capital_allocated = 100.0  # can't afford even one 75-lot at any real premium
        self._warmup()
        self.engine.feed_candles([1, 100.5, 101.5, 100.2, 101.0, 999],
                                  [1, 100.5, 101.5, 100.2, 101.0, 2000], "09:45:00", is_backfill=False)
        self.engine.feed_candles([2, 101.0, 102.0, 100.8, 101.8, 999],
                                  [2, 101.0, 102.0, 100.8, 101.8, 2200], "09:50:00", is_backfill=False)
        self.assertFalse(self.engine.option.is_open)
        self.assertEqual(self.engine.trade_book.trades, [])


class TestNiftyOptionsEngineShortBias(unittest.TestCase):
    """Mirror image of the LONG tests, reusing test_signal_engine.py's SHORT warm-up pattern
    (or_low=100.0, base trending down from 105)."""

    def setUp(self):
        self.orig_dry_run = config.DRY_RUN
        config.DRY_RUN = True
        data_service = FakeQuoteDataService(spot=None, option_prices=80.0)
        self.engine = NiftyOptionsEngine(data_service, option_symbol="NSE:NIFTY25O1424800PE",
                                          option_lot_size=75, bias_direction=TradeDirection.SHORT,
                                          index_or_high=100.0, index_or_low=100.0,
                                          capital_allocated=200_000.0)

    def tearDown(self):
        config.DRY_RUN = self.orig_dry_run

    def _warmup(self, count=20, volume=1000):
        for i in range(count):
            c = 105 - i * 0.05
            index_candle = [1700000000 + i, c, c + 0.2, c - 0.2, c, 1000]
            futures_candle = [1700000000 + i, c, c + 0.2, c - 0.2, c, volume]
            self.engine.feed_candles(index_candle, futures_candle, f"09:{20 + i}:00", is_backfill=False)

    def test_entry_fires_on_index_breakdown_confirmed_by_futures_volume(self):
        self._warmup()
        self.engine.feed_candles([1, 99.5, 99.8, 98.5, 99.0, 999],
                                  [1, 99.5, 99.8, 98.5, 99.0, 2000], "09:45:00", is_backfill=False)
        self.engine.feed_candles([2, 99.0, 99.2, 97.8, 98.2, 999],
                                  [2, 99.0, 99.2, 97.8, 98.2, 2200], "09:50:00", is_backfill=False)

        self.assertTrue(self.engine.option.is_open)
        self.assertEqual(self.engine.option.entry_price, 80.0)

    def test_exit_fires_on_index_closing_above_vwap_confirmed_by_futures_volume(self):
        self._warmup()
        self.engine.feed_candles([1, 99.5, 99.8, 98.5, 99.0, 999],
                                  [1, 99.5, 99.8, 98.5, 99.0, 2000], "09:45:00", is_backfill=False)
        self.engine.feed_candles([2, 99.0, 99.2, 97.8, 98.2, 999],
                                  [2, 99.0, 99.2, 97.8, 98.2, 2200], "09:50:00", is_backfill=False)
        self.assertTrue(self.engine.option.is_open)

        self.engine.feed_candles([3, 105.0, 106.5, 104.5, 106.0, 999],
                                  [3, 105.0, 106.5, 104.5, 106.0, 3000], "09:55:00", is_backfill=False)
        self.engine.feed_candles([4, 106.0, 109.0, 105.5, 108.0, 999],
                                  [4, 106.0, 109.0, 105.5, 108.0, 3500], "10:00:00", is_backfill=False)

        self.assertFalse(self.engine.option.is_open)


class TestNiftyOptionsEngineMisc(unittest.TestCase):
    def setUp(self):
        self.orig_dry_run = config.DRY_RUN
        config.DRY_RUN = True

    def tearDown(self):
        config.DRY_RUN = self.orig_dry_run

    def test_trackers_property_exposes_only_the_futures_tracker_for_seeding(self):
        data_service = FakeQuoteDataService(spot=None, option_prices=150.0)
        engine = NiftyOptionsEngine(data_service, option_symbol="NSE:NIFTY25O1425000CE",
                                     option_lot_size=75, bias_direction=TradeDirection.LONG,
                                     index_or_high=100.0, index_or_low=100.0, capital_allocated=200_000.0)
        self.assertEqual(set(engine.trackers), {config.NIFTY_FUTURES_SYMBOL})

    def test_square_off_all_is_a_no_op_when_nothing_is_open(self):
        data_service = FakeQuoteDataService(spot=None, option_prices=150.0)
        engine = NiftyOptionsEngine(data_service, option_symbol="NSE:NIFTY25O1425000CE",
                                     option_lot_size=75, bias_direction=TradeDirection.LONG,
                                     index_or_high=100.0, index_or_low=100.0, capital_allocated=200_000.0)
        engine.square_off_all()  # should not raise
        self.assertEqual(engine.trade_book.trades, [])

    def test_square_off_all_closes_an_open_position(self):
        data_service = FakeQuoteDataService(spot=None, option_prices=150.0)
        engine = NiftyOptionsEngine(data_service, option_symbol="NSE:NIFTY25O1425000CE",
                                     option_lot_size=75, bias_direction=TradeDirection.LONG,
                                     index_or_high=100.0, index_or_low=100.0, capital_allocated=200_000.0)
        engine.option.is_open = True
        engine.option.entry_price = 140.0
        engine.option.qty = 75
        engine.trade_book.record_entry(engine.option.symbol, "09:45:00", 140.0, qty=75,
                                        direction=TradeDirection.LONG)
        engine.square_off_all(at_time_str="15:10:30")
        self.assertFalse(engine.option.is_open)
        trade = engine.trade_book.trades[0]
        self.assertEqual(trade["exit_price"], 150.0)
        self.assertEqual(trade["exit_time"], "15:10:30")

    def test_check_all_skips_the_tick_when_either_candle_is_missing(self):
        data_service = FakeFullDataService(spot=None, candles_by_symbol={config.NIFTY_INDEX_SYMBOL:
                                                                           [1, 100, 101, 99, 100, 0]})
        # futures candle missing entirely from candles_by_symbol
        engine = NiftyOptionsEngine(data_service, option_symbol="NSE:NIFTY25O1425000CE",
                                     option_lot_size=75, bias_direction=TradeDirection.LONG,
                                     index_or_high=100.0, index_or_low=100.0, capital_allocated=200_000.0)
        engine.check_all(1700000000, 1700000300)  # should not raise
        self.assertFalse(engine.option.is_open)
        self.assertEqual(len(engine.index_tracker.candles), 0)  # never got as far as updating either tracker


# ----------------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------------
class TestRunNiftyOptionsEngine(unittest.TestCase):
    def setUp(self):
        self._orig_capital = config.NIFTY_OPTIONS_CAPITAL
        config.NIFTY_OPTIONS_CAPITAL = 200_000.0

    def tearDown(self):
        config.NIFTY_OPTIONS_CAPITAL = self._orig_capital

    def test_long_bias_buys_a_call(self):
        master = _sample_master()
        index_candle = [1234567890, 24900.0, 24950.0, 24880.0, 24920.0, 0]
        data_service = FakeFullDataService(spot=24_910.0, candles_by_symbol={config.NIFTY_INDEX_SYMBOL: index_candle})
        engine = options_engine.run_nifty_options_engine(data_service, TradeDirection.LONG, symbol_master=master)
        self.assertIsNotNone(engine)
        self.assertIn("CE", engine.option.symbol)
        self.assertEqual(engine.option.lot_size, 75)
        self.assertEqual(engine.option.capital_allocated, 200_000.0)
        self.assertEqual(engine.bias_direction, TradeDirection.LONG)
        self.assertEqual(engine.index_tracker.or_high, 24950.0)
        self.assertEqual(engine.index_tracker.or_low, 24880.0)

    def test_short_bias_buys_a_put(self):
        master = _sample_master()
        index_candle = [1234567890, 24900.0, 24950.0, 24880.0, 24920.0, 0]
        data_service = FakeFullDataService(spot=24_910.0, candles_by_symbol={config.NIFTY_INDEX_SYMBOL: index_candle})
        engine = options_engine.run_nifty_options_engine(data_service, TradeDirection.SHORT, symbol_master=master)
        self.assertIsNotNone(engine)
        self.assertIn("PE", engine.option.symbol)
        self.assertEqual(engine.bias_direction, TradeDirection.SHORT)

    def test_unresolvable_contract_returns_none(self):
        data_service = FakeFullDataService(spot=24_910.0, candles_by_symbol={})
        engine = options_engine.run_nifty_options_engine(data_service, TradeDirection.LONG,
                                                           symbol_master=pd.DataFrame())
        self.assertIsNone(engine)

    def test_missing_opening_range_candle_returns_none(self):
        master = _sample_master()
        data_service = FakeFullDataService(spot=24_910.0, candles_by_symbol={})  # resolves fine, no OR candle
        engine = options_engine.run_nifty_options_engine(data_service, TradeDirection.LONG, symbol_master=master)
        self.assertIsNone(engine)


if __name__ == "__main__":
    unittest.main(verbosity=2)
