"""
Main CLI Entrypoint for Ghanshyam Trader (Backtesting & Realtime Session Modes)
"""

import argparse
import logging
import sys
from datetime import datetime, date, time, timedelta
from typing import Dict, List, Optional, Tuple

from config import IndexConfig
from models import Candle, Direction, LDCHLLevels
from backtester import BacktestEngine
from realtime_runner import MultiAssetTradingManager, RealtimeSessionRunner

logger = logging.getLogger("GhanshyamTradingSystem")


def fetch_fyers_multiday_data(
    fyers_client=None,
    expiry: str = "26OCT",
    range_from: Optional[str] = None,
    range_to: Optional[str] = None,
    num_days: int = 5,
    resolution: str = "5"
) -> Tuple[Dict[date, Dict[str, List[Candle]]], Dict[date, Dict[str, List[float]]], Dict[date, Dict[str, LDCHLLevels]]]:
    """
    Fetches historical 5-minute candle data directly from Fyers API v3 via fyers_client.history():
    1. Futures Candles: Used for technical signal generation (NIFTY FUT & BANKNIFTY FUT).
    2. Base Spot Index Prices: Used for ITM Option Strike selection (NIFTY 50 & BANK NIFTY Spot).
    3. Dynamic LDCHL: Previous Day High, Low, Close benchmarks calculated automatically.
    """
    fut_symbols = {
        "BANKNIFTY": f"NSE:BANKNIFTY{expiry.upper()}FUT",
        "NIFTY": f"NSE:NIFTY{expiry.upper()}FUT"
    }

    spot_symbols = {
        "BANKNIFTY": "NSE:NIFTYBANK-INDEX",
        "NIFTY": "NSE:NIFTY50-INDEX"
    }

    if not range_to:
        range_to = datetime.now().strftime("%Y-%m-%d")

    if not range_from:
        lookback = max(num_days * 2, 10)
        range_from = (datetime.now() - timedelta(days=lookback)).strftime("%Y-%m-%d")

    fut_candles_by_date: Dict[date, Dict[str, List[Candle]]] = {}
    spot_prices_by_date: Dict[date, Dict[str, List[float]]] = {}

    if fyers_client and hasattr(fyers_client, "history"):
        print(f"\n[Fyers API] Fetching Futures candles ({list(fut_symbols.values())}) & Spot Index prices [{range_from} to {range_to}]...")
        
        # 1. Fetch Futures Candles
        for code, fut_sym in fut_symbols.items():
            req_data = {
                "symbol": fut_sym,
                "resolution": resolution,
                "date_format": "1",
                "range_from": range_from,
                "range_to": range_to,
                "cont_flag": "1"
            }
            res = fyers_client.history(data=req_data)
            if res and res.get("s") == "ok":
                raw_candles = res.get("candles", [])
                for c in raw_candles:
                    dt = datetime.fromtimestamp(c[0])
                    c_date = dt.date()
                    candle_obj = Candle(
                        timestamp=dt,
                        open=float(c[1]),
                        high=float(c[2]),
                        low=float(c[3]),
                        close=float(c[4]),
                        volume=float(c[5]) if len(c) > 5 else 0.0
                    )
                    if c_date not in fut_candles_by_date:
                        fut_candles_by_date[c_date] = {}
                    if code not in fut_candles_by_date[c_date]:
                        fut_candles_by_date[c_date][code] = []
                    fut_candles_by_date[c_date][code].append(candle_obj)

        # 2. Fetch Spot Index Prices (for base index strike selection)
        for code, spot_sym in spot_symbols.items():
            req_data = {
                "symbol": spot_sym,
                "resolution": resolution,
                "date_format": "1",
                "range_from": range_from,
                "range_to": range_to,
                "cont_flag": "1"
            }
            res = fyers_client.history(data=req_data)
            if res and res.get("s") == "ok":
                raw_candles = res.get("candles", [])
                for c in raw_candles:
                    dt = datetime.fromtimestamp(c[0])
                    c_date = dt.date()
                    spot_price = float(c[4])  # Close price of spot bar
                    if c_date not in spot_prices_by_date:
                        spot_prices_by_date[c_date] = {}
                    if code not in spot_prices_by_date[c_date]:
                        spot_prices_by_date[c_date][code] = []
                    spot_prices_by_date[c_date][code].append(spot_price)

    if not fut_candles_by_date:
        print("[Info] fyers_client not provided or returned no candles. Using fallback Futures & Spot demonstration dataset.")
        fut_candles_by_date, spot_prices_by_date = generate_mock_multiday_data(num_days=num_days)

    sorted_dates = sorted(fut_candles_by_date.keys())
    ldc_by_date: Dict[date, Dict[str, LDCHLLevels]] = {}

    for idx, current_date in enumerate(sorted_dates):
        ldc_by_date[current_date] = {}
        if idx > 0:
            prev_date = sorted_dates[idx - 1]
            for code in fut_candles_by_date[current_date].keys():
                prev_candles = fut_candles_by_date[prev_date].get(code, [])
                if prev_candles:
                    pdh = max(c.high for c in prev_candles)
                    pdl = min(c.low for c in prev_candles)
                    pdc = prev_candles[-1].close
                    trend = Direction.BULLISH if pdc >= prev_candles[0].open else Direction.BEARISH
                    ldc_by_date[current_date][code] = LDCHLLevels(pdh=pdh, pdl=pdl, pdc=pdc, daily_trend=trend)
        else:
            for code in fut_candles_by_date[current_date].keys():
                day_c = fut_candles_by_date[current_date][code]
                if day_c:
                    ldc_by_date[current_date][code] = LDCHLLevels(
                        pdh=max(c.high for c in day_c),
                        pdl=min(c.low for c in day_c),
                        pdc=day_c[-1].close,
                        daily_trend=Direction.BULLISH
                    )

    return fut_candles_by_date, spot_prices_by_date, ldc_by_date


def generate_mock_multiday_data(num_days: int = 5) -> Tuple[Dict[date, Dict[str, List[Candle]]], Dict[date, Dict[str, List[float]]]]:
    """Generates synthetic Futures candles and Base Spot Index prices for demonstration."""
    fut_data = {}
    spot_data = {}
    base_date = date(2026, 10, 12)

    for d in range(num_days):
        current_date = base_date + timedelta(days=d)
        bn_fut_candles = []
        nf_fut_candles = []
        bn_spot_prices = []
        nf_spot_prices = []

        bn_p_fut = 51600.0 + (d * 100.0)
        nf_p_fut = 24450.0 + (d * 50.0)

        start_dt = datetime.combine(current_date, time(9, 15))

        for b in range(75):
            bar_ts = start_dt + timedelta(minutes=5 * b)

            # Futures Candles
            bn_high = bn_p_fut + (20.0 if b % 2 == 0 else 80.0)
            bn_low = bn_p_fut - (15.0 if b % 3 == 0 else 50.0)
            bn_close = bn_high - 10.0 if b % 2 == 0 else bn_low + 10.0
            bn_fut_candles.append(Candle(bar_ts, bn_p_fut, bn_high, bn_low, bn_close, volume=1000))
            bn_p_fut = bn_close
            bn_spot_prices.append(bn_close - 50.0)  # Spot index trades at ~50 pt discount/premium

            nf_high = nf_p_fut + (10.0 if b % 2 == 0 else 35.0)
            nf_low = nf_p_fut - (8.0 if b % 3 == 0 else 25.0)
            nf_close = nf_high - 5.0 if b % 2 == 0 else nf_low + 5.0
            nf_fut_candles.append(Candle(bar_ts, nf_p_fut, nf_high, nf_low, nf_close, volume=2000))
            nf_p_fut = nf_close
            nf_spot_prices.append(nf_close - 20.0)  # Spot index trades at ~20 pt discount/premium

        fut_data[current_date] = {
            "BANKNIFTY": bn_fut_candles,
            "NIFTY": nf_fut_candles
        }

        spot_data[current_date] = {
            "BANKNIFTY": bn_spot_prices,
            "NIFTY": nf_spot_prices
        }

    return fut_data, spot_data


def run_backtest_mode(
    capital: float,
    expiry: str,
    fyers_client=None,
    range_from: Optional[str] = None,
    range_to: Optional[str] = None,
    export_csv_path: str = "trades_export.csv"
):
    """Executes multi-day historical backtest using Futures signals and Base Spot Index strikes."""
    print("\n" + "=" * 80)
    print("   RUNNING HISTORICAL MULTI-DAY BACKTESTING ENGINE (FUT SIGNALS / SPOT STRIKES)")
    print("=" * 80)

    engine = BacktestEngine(initial_capital=capital, banknifty_expiry=expiry, nifty_expiry=expiry)

    fut_data, spot_data, ldc_by_date = fetch_fyers_multiday_data(
        fyers_client=fyers_client,
        expiry=expiry,
        range_from=range_from,
        range_to=range_to,
        num_days=5
    )

    result = engine.run_backtest(fut_data, spot_prices_by_date=spot_data, daily_ldc_by_date=ldc_by_date)
    result.print_daily_pnl_table()

    if export_csv_path:
        csv_file = result.export_trades_to_csv(filepath=export_csv_path)
        print(f"[CSV Export] All {result.total_trades} trades successfully exported to: {csv_file}\n")


def run_realtime_mode(
    capital: float,
    expiry: str,
    is_live: bool = False,
    fyers_client=None,
    export_csv_path: str = "trades_export.csv"
):
    """Executes live/paper trading session (09:15 to 15:30 IST) using Futures signals and Base Spot Index strikes."""
    manager = MultiAssetTradingManager(
        total_capital=capital,
        fyers_client=fyers_client,
        is_paper=not is_live,
        banknifty_expiry=expiry,
        nifty_expiry=expiry
    )

    if fyers_client:
        manager.auto_fetch_levels_from_fyers(fyers_client)
    else:
        manager.set_levels("BANKNIFTY", pdh=52000.0, pdl=51000.0, pdc=51500.0, trend=Direction.BULLISH)
        manager.set_levels("NIFTY", pdh=24600.0, pdl=24300.0, pdc=24450.0, trend=Direction.BULLISH)

    runner = RealtimeSessionRunner(manager)

    fut_data, spot_data = generate_mock_multiday_data(num_days=1)
    today_dt = list(fut_data.keys())[0]

    bn_fut_candles = fut_data[today_dt]["BANKNIFTY"]
    nf_fut_candles = fut_data[today_dt]["NIFTY"]

    bn_spot_prices = spot_data[today_dt]["BANKNIFTY"]
    nf_spot_prices = spot_data[today_dt]["NIFTY"]

    runner.run_simulated_session(
        bn_fut_candles,
        nf_fut_candles,
        bn_spot_prices=bn_spot_prices,
        nf_spot_prices=nf_spot_prices,
        export_csv_path=export_csv_path
    )


def main():
    parser = argparse.ArgumentParser(description="Ghanshyam Tech Multi-Asset Options Trading Agent (Futures Signals / Spot Strikes)")
    parser.add_argument("--mode", type=str, choices=["backtest", "realtime", "live"], default="backtest",
                        help="Execution mode: 'backtest' (multi-day historical test), 'realtime' (paper simulation), or 'live' (Fyers API)")
    parser.add_argument("--capital", type=float, default=500000.0, help="Initial trading capital in INR (default: 500000)")
    parser.add_argument("--expiry", type=str, default="26OCT", help="Option expiry string e.g. '26OCT'")
    parser.add_argument("--range-from", type=str, default=None, help="Backtest start date 'YYYY-MM-DD'")
    parser.add_argument("--range-to", type=str, default=None, help="Backtest end date 'YYYY-MM-DD'")
    parser.add_argument("--export-csv", type=str, default="trades_export.csv", help="CSV filename to export all trade records (default: 'trades_export.csv')")
    parser.add_argument("--client-id", type=str, default=None, help="Fyers API Client ID (required for live mode)")
    parser.add_argument("--access-token", type=str, default=None, help="Fyers API Access Token (required for live mode)")

    args = parser.parse_args()

    fyers_client = None
    if args.client_id and args.access_token:
        try:
            from fyers_apiv3 import fyersModel
            fyers_client = fyersModel.FyersModel(client_id=args.client_id, token=args.access_token, is_async=False, log_path="")
            print("Successfully authenticated live Fyers API client.")
        except ImportError:
            print("fyers_apiv3 library not found. Install via 'pip install fyers-apiv3'")
            sys.exit(1)

    if args.mode == "backtest":
        run_backtest_mode(
            capital=args.capital,
            expiry=args.expiry,
            fyers_client=fyers_client,
            range_from=args.range_from,
            range_to=args.range_to,
            export_csv_path=args.export_csv
        )
    else:
        run_realtime_mode(
            capital=args.capital,
            expiry=args.expiry,
            is_live=(args.mode == "live"),
            fyers_client=fyers_client,
            export_csv_path=args.export_csv
        )


if __name__ == "__main__":
    main()
