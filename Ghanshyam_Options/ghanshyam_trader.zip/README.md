# Ghanshyam Tech Index Options Trading & Backtesting System (Futures Signals / Base Index Strikes)

An institutional-grade, fully modular Python trading system implementing the **Ghanshyam Tech price action and behavioral risk management methodology** for both **BANK NIFTY** and **NIFTY 50** options.

---

## ⚡ Key Dual-Instrument Capability

1. **Signal Generation Source**: Evaluates 5-minute price action candles from **NIFTY 50 FUT** (`NSE:NIFTY{EXPIRY}FUT`) and **BANK NIFTY FUT** (`NSE:BANKNIFTY{EXPIRY}FUT`) to trigger technical setups (9:20 AM Opening Range, Bullish Hammer, Bearish Shooting Star, Inside Candle Compression, 2:20 PM Momentum).
2. **Option Strike Price Selection**: Computes 1-strike In-The-Money (ITM) option contracts using the **Base Spot Index LTP** (`NSE:NIFTY50-INDEX` / `NSE:NIFTYBANK-INDEX`).

---

## Key Features

- **Flat Direct Imports**: Execute scripts directly inside the folder without needing `python -m package` wrappers or setuptools installation.
- **Multi-Index Support**: Concurrently trades **BANK NIFTY** (100-pt strike step, 15 lot size) and **NIFTY 50** (50-pt strike step, 25 lot size) under a shared account-level risk engine.
- **Fyers API v3 Integration**: Live historical 5-min candle ingestion, quotes polling, and order routing via `fyers_client`.
- **High-Fidelity Paper Trading Engine**: Realistic order execution modeling bid-ask slippage, ₹20/order exchange fees, position tracking, and margin ledger.
- **Historical Backtesting Engine**: Replays multi-day 5-minute candle data day-by-day and outputs a **Date-by-Date Daily PnL Table** with win rate, profit factor, drawdown, and net returns.
- **Automatic CSV Trade Export**: Writes all executed trades with entry/exit timestamps, spot/option prices, PnL, and setup rationale to `trades_export.csv`.
- **Real-Time Intraday Session Runner**: Runs continuously from **Market Open (09:15 IST) to Market Close (15:30 IST)**, generating signals, managing paper/live positions, and enforcing a mandatory **15:15 IST EOD auto-square-off**.

---

## Directory Structure & Files

```text
ghanshyam_trader/
├── config.py           # Index parameters (Futures & Spot symbols, strike steps, lot sizes, time gates)
├── models.py           # Dataclasses: Candle, LDCHLLevels, TradeSignal, Position, Direction, OptionType
├── strategies.py       # Price action setups (9:20 AM, Hammer, Shooting Star, Inside Candle, 2:20 PM)
├── strikes.py          # ITM strike selection (Delta 0.55-0.70) and Fyers symbol formatting
├── risk.py             # Behavioral Risk Engine (25% tranche, 80/20 Profit Lock, 2-loss lockout)
├── broker.py           # PaperTradingBroker & FyersClientAdapter (with CSV trade logging)
├── agent.py            # IndexTradingAgent (Single index setup evaluation & trade lifecycle)
├── backtester.py       # BacktestEngine with Date-by-Date Daily PnL summary table
├── realtime_runner.py  # MultiAssetTradingManager & RealtimeSessionRunner (09:15 - 15:30 IST)
├── main.py             # Main CLI Entrypoint (run via python main.py)
├── test_ghanshyam_agent.py # Unit test suite
├── trades_export.csv   # Automatically exported CSV trade log
└── README.md           # Documentation
```

---

## Strategic Price Action Setups Implemented

1. **09:20 AM Opening Volatility Strategy**:
   - Evaluates the opening 5-minute Futures candle (09:15 - 09:20 IST).
   - Rejects the setup if the opening range exceeds **250 spot points in Bank Nifty** or **120 spot points in Nifty** (volatility range exhaustion).
   - Triggers on a breakout above the high (Call) or breakdown below the low (Put).
2. **Bullish Hammer Reversal Strategy**:
   - Pre-condition: Requires an uninterrupted downfall of **≥ 100 pts (Bank Nifty)** or **≥ 50 pts (Nifty)** on the Futures chart.
   - Wick morphology: Lower shadow ≥ 2x real body; upper shadow ≤ 25% total range.
   - Triggers when subsequent price breaches the Hammer high.
3. **Bearish Shooting Star Reversal Strategy**:
   - Pre-condition: Requires an uninterrupted upward rally of **≥ 100 pts (Bank Nifty)** or **≥ 50 pts (Nifty)** on the Futures chart.
   - Wick morphology: Upper shadow ≥ 2x real body; lower shadow ≤ 25% total range.
   - Triggers when subsequent price breaches the Shooting Star low.
4. **Inside Candle Compression Strategy**:
   - Identifies volatility contraction where a 5-minute child candle range is fully enveloped inside the preceding mother candle.
   - Triggers on breakout of child candle extreme; risk is capped strictly to child candle range.
5. **02:20 PM Institutional Momentum Strategy**:
   - Captures afternoon volatility surges (14:20 IST Futures candle breakout) driven by European market opening liquidity transitions.

---

## Behavioral Risk & Capital Preservation Rules (Ghanshyam Doctrine)

- **Tranche Capital Allocation**: Strictly caps active capital deployment to **20%–25% of total account equity** per trade tranche.
- **80/20 Profit Retention Rule ("A green session must never close red")**: Once a daily profit peak is hit, **80% of peak gains are locked**. Subsequent trades can only risk the remaining 20%.
- **Consecutive Loss Lockout**: Mandatory terminal shutdown after **2 consecutive stop-outs** to prevent emotional revenge trading.
- **Daily Trade Ceiling**: Absolute hard cap of **2 to 3 trades max** per session across all assets combined.
- **Max Account Drawdown Circuit Breaker**: Hard exit if account equity drops by **2%–3%** in a single session.
- **Asymmetric Sizing**: 100% position sizing for trend-aligned setups, **50% sizing** for counter-trend setups.

---

## Quick Execution Guide

### 1. Run Multi-Day Historical Backtest
`cd` into the folder and execute `main.py`:

```bash
cd ghanshyam_trader
python main.py --mode backtest --capital 500000 --expiry 26OCT
```

**Outputs Date-by-Date Daily PnL Table & Exports CSV:**
```text
=========================================================================================================
DATE         | TRADES | WINS | LOSS | NET PNL (₹)    | BALANCE (₹)    | PEAK PROFIT  | STATUS              
=========================================================================================================
2026-10-12   | 4      | 2    | 2    | ₹-12,400.00    | ₹487,600.00    | ₹2,187.50    | LOCKED OUT          
2026-10-13   | 4      | 2    | 2    | ₹-12,400.00    | ₹475,200.00    | ₹2,187.50    | LOCKED OUT          
2026-10-14   | 4      | 2    | 2    | ₹-12,400.00    | ₹462,800.00    | ₹2,187.50    | LOCKED OUT          
2026-10-15   | 4      | 2    | 2    | ₹-12,400.00    | ₹450,400.00    | ₹2,187.50    | LOCKED OUT          
2026-10-16   | 4      | 2    | 2    | ₹-12,400.00    | ₹438,000.00    | ₹2,187.50    | LOCKED OUT          
=========================================================================================================
```

### 2. Run Real-Time Session Simulation (Paper Trading)
```bash
python main.py --mode realtime --capital 500000 --expiry 26OCT --export-csv my_session.csv
```

### 3. Run Live Execution via Fyers API v3
```bash
python main.py --mode live --capital 500000 --client-id YOUR_FYERS_CLIENT_ID --access-token YOUR_ACCESS_TOKEN
```

### 4. Run Unit Test Suite
```bash
python -m unittest test_ghanshyam_agent.py
```
