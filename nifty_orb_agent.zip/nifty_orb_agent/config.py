"""
config.py
----------
Centralised configuration for the Opening Range Breakout (ORB) scanning agent.

All secrets are read from environment variables (via a local `.env` file) so
credentials never get hard-coded or committed to source control. Copy
`.env.example` to `.env` and fill in your own values before running anything.
"""

from __future__ import annotations

import os
from dotenv import load_dotenv

load_dotenv()  # loads variables from a local .env file, if present

# ----------------------------------------------------------------------------
# Fyers API credentials (create an app at https://myapi.fyers.in)
# ----------------------------------------------------------------------------
FYERS_APP_ID = os.getenv("FYERS_APP_ID", "")            # e.g. "ABCDE12345-100"
FYERS_SECRET_KEY = os.getenv("FYERS_SECRET_KEY", "")
FYERS_REDIRECT_URI = os.getenv("FYERS_REDIRECT_URI", "")
FYERS_FY_ID = os.getenv("FYERS_FY_ID", "")               # your Fyers login id (e.g. XY01234)
FYERS_PIN = os.getenv("FYERS_PIN", "")                   # 4-digit trading PIN
FYERS_TOTP_SECRET = os.getenv("FYERS_TOTP_SECRET", "")   # from Fyers > Profile > 2FA setup

# Optional: only needed if you enable the LLM-based macro/geopolitical news
# sentiment helper in global_sentiment.get_llm_news_sentiment()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# ----------------------------------------------------------------------------
# File paths
# ----------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")

STOCK_UNIVERSE_CSV = os.path.join(DATA_DIR, "ind_nifty500list.csv")     # see README for download link
SECTOR_INDEX_MAP_CSV = os.path.join(DATA_DIR, "sector_index_map.csv")  # symbol -> sector mapping
LOG_FILE = os.path.join(LOG_DIR, "orb_agent.log")
TRADE_LOG_CSV = os.path.join(LOG_DIR, "trade_book_{date}.csv")

# ----------------------------------------------------------------------------
# Timing (all times are IST / Asia/Kolkata, weekdays only)
# ----------------------------------------------------------------------------
TIMEZONE = "Asia/Kolkata"

SECTOR_SCAN_TIME = "09:10:00"           # pre-open sector snapshot (see caveat in sector_scanner.py)
OPENING_RANGE_SCAN_TIME = "09:20:02"    # 2s buffer after the 09:15-09:20 candle closes
SIGNAL_ENGINE_LAST_RUN = "15:10:00"     # stop looking for NEW signals after this time
SQUARE_OFF_TIME = "15:10:30"            # force-close any open paper positions
CANDLE_INTERVAL_MINUTES = 5

# ----------------------------------------------------------------------------
# Strategy parameters
# ----------------------------------------------------------------------------
MIN_GAIN_PCT = 0.5       # lower bound (exclusive) for the opening-range gainer filter
MAX_GAIN_PCT = 2.5       # upper bound (inclusive) for the opening-range gainer filter
TOP_N_STOCKS = 5          # how many stocks to shortlist and track intraday
VOLUME_MA_PERIOD = 20     # number of 5-min candles for the volume moving average
CONSECUTIVE_CANDLES_FOR_BUY = 2  # candles required to confirm a breakout

# Retry / resilience for API calls
API_MAX_RETRIES = 3
API_RETRY_BACKOFF_SECONDS = 2

# Dry-run: when True (default) the agent only *simulates* trades in memory and
# CSV, and NEVER calls fyers.place_order(). Only flip to False after you have
# paper-traded the logic for a good stretch and understand the risk involved
# (see README "Before you go live").
DRY_RUN = True
