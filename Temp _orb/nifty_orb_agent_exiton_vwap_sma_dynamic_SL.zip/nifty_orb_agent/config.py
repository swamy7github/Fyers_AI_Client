"""
config.py
----------
Centralised configuration for the Opening Range Breakout (ORB) scanning agent.

All secrets are read from environment variables (via a local `.env` file) so
credentials never get hard-coded or committed to source control. Copy
`.env.example` to `.env` and fill in your own values before running anything.
"""

from __future__ import annotations

import os
from dotenv import load_dotenv

load_dotenv()  # loads variables from a local .env file, if present

# ----------------------------------------------------------------------------
# Fyers API credentials (create an app at https://myapi.fyers.in)
# ----------------------------------------------------------------------------
FYERS_APP_ID = os.getenv("FYERS_APP_ID", "")            # e.g. "ABCDE12345-100"
FYERS_SECRET_KEY = os.getenv("FYERS_SECRET_KEY", "")
FYERS_REDIRECT_URI = os.getenv("FYERS_REDIRECT_URI", "")
FYERS_FY_ID = os.getenv("FYERS_FY_ID", "")               # your Fyers login id (e.g. XY01234)
FYERS_PIN = os.getenv("FYERS_PIN", "")                   # 4-digit trading PIN
FYERS_TOTP_SECRET = os.getenv("FYERS_TOTP_SECRET", "")   # from Fyers > Profile > 2FA setup

# Optional: only needed if you enable the LLM-based macro/geopolitical news
# sentiment helper in global_sentiment.get_llm_news_sentiment()
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")

# ----------------------------------------------------------------------------
# File paths
# ----------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
LOG_DIR = os.path.join(BASE_DIR, "logs")

STOCK_UNIVERSE_CSV = os.path.join(DATA_DIR, "ind_nifty500list.csv")     # see README for download link
SECTOR_INDEX_MAP_CSV = os.path.join(DATA_DIR, "sector_index_map.csv")  # symbol -> sector mapping
LOG_FILE = os.path.join(LOG_DIR, "orb_agent.log")
TRADE_LOG_CSV = os.path.join(LOG_DIR, "trade_book_{date}.csv")

# ----------------------------------------------------------------------------
# Timing (all times are IST / Asia/Kolkata, weekdays only)
# ----------------------------------------------------------------------------
TIMEZONE = "Asia/Kolkata"

SECTOR_SCAN_TIME = "09:10:00"           # pre-open sector snapshot (see caveat in sector_scanner.py)
SECTOR_SCAN_TIME_POSTOPEN = "09:16:00"  # re-run shortly after the normal session starts, for real numbers
OPENING_RANGE_SCAN_TIME = "09:20:02"    # 2s buffer after the 09:15-09:20 candle closes
SIGNAL_ENGINE_LAST_RUN = "15:10:00"     # stop looking for NEW signals after this time
SQUARE_OFF_TIME = "15:10:30"            # force-close any open paper positions
CANDLE_INTERVAL_MINUTES = 5

# NSE's actual normal-session hours. Used only to decide whether a late
# application startup falls "within trading hours" for the catch-up logic in
# main.py - does NOT account for NSE trading holidays, which is a separate
# concern this scaffold doesn't cover (a holiday calendar check would need
# to be layered on top before relying on this for unattended daily runs).
MARKET_OPEN_TIME = "09:15:00"
MARKET_CLOSE_TIME = "15:30:00"

# job_opening_range_scan() uses the fast quotes-proxy method (valid only
# right at 09:20:02, see opening_range_scanner.py) when called within this
# many seconds of OPENING_RANGE_SCAN_TIME, and automatically falls back to
# the slower-but-always-correct historical-candle method otherwise (e.g. on
# a late/catch-up start). See job_opening_range_scan in main.py.
OPENING_RANGE_FAST_PATH_TOLERANCE_SECONDS = 180

# Fyers' documented per-request limits for the historical /history endpoint
# (confirmed via their own API docs and community forum, including an
# actual -339 error for exceeding the daily one): up to 100 days per request
# for intraday resolutions (1/2/3/5/10/15/20/30/45/60/120/180/240 min), and
# up to ~365-366 days per request for daily ('D') resolution. backtest.py
# chunks any longer requested range into calls no larger than these.
# Verify against your own account/plan before relying on it for a long
# backtest - these are Fyers-side limits that could change.
INTRADAY_HISTORY_MAX_DAYS_PER_CHUNK = 100
DAILY_HISTORY_MAX_DAYS_PER_CHUNK = 365

# ----------------------------------------------------------------------------
# Strategy parameters
# ----------------------------------------------------------------------------
MIN_GAIN_PCT = 0.5       # lower bound (exclusive) for the opening-range gainer filter (LONG side)
MAX_GAIN_PCT = 2.5       # upper bound (inclusive) for the opening-range gainer filter (LONG side)

# Mirror of the above for the SHORT side: a stock down between MIN_LOSS_PCT and MAX_LOSS_PCT
# (both positive numbers here, representing the magnitude of the decline) is eligible for
# the gap-down/breakdown screen. See opening_range_scanner.scan_opening_range(direction=...).
MIN_LOSS_PCT = 0.5
MAX_LOSS_PCT = 2.5

TOP_N_STOCKS = 5          # how many stocks to shortlist and track intraday
VOLUME_MA_PERIOD = 20     # number of 5-min candles for the ENTRY volume moving average
CONSECUTIVE_CANDLES_FOR_BUY = 2  # candles required to confirm a breakout entry

# ---- Directional gating from global sentiment (see trade_direction.py) ----
# When global_sentiment.score_global_bias() (or get_stock_news_ema_bias's combined_bias)
# comes back NEUTRAL/MIXED/UNKNOWN rather than a clear BULLISH or BEARISH, these decide
# whether to still trade a direction anyway. Both False (the default) means: no clear
# sentiment -> open no new positions that day, in either direction - a deliberately
# conservative default. Set either to True to fall back to that direction specifically
# when sentiment is unclear, rather than sitting out entirely.
ALLOW_LONG_ON_NEUTRAL = False
ALLOW_SHORT_ON_NEUTRAL = False

# ---- Stop-loss / square-off & position-sizing (add-on) parameters ----
# Weakness/breakdown is detected with the SAME 20-period volume MA
# (VOLUME_MA_PERIOD above) used for entries - two consecutive candles closing
# against the position, with volume above that 20-period average, confirm
# the exit/add-on signal. (Earlier revisions used a separate, faster 2-period
# volume average here; that has been replaced so entry and exit share one
# volume-conviction bar.)
CONSECUTIVE_CANDLES_FOR_STOPLOSS = 2

# The FIRST time the weakness pattern appears after a buy (no square-off has
# fired yet on this position), the engine adds to the position instead of
# exiting - up to MAX_POSITION_ADDS times. Any weakness event beyond that
# triggers a full square-off of the whole position (all adds included).
# Set MAX_POSITION_ADDS = 0 to disable adding and square off on the very
# first weakness event instead.
MAX_POSITION_ADDS = 1

# Retry / resilience for API calls
API_MAX_RETRIES = 3
API_RETRY_BACKOFF_SECONDS = 2

# Rate-limit-SPECIFIC retry handling (see fyers_service._looks_like_rate_limit_error),
# separate from the generic linear-backoff retries above - a rejection that's
# genuinely "you're being rate limited" warrants more attempts with an exponentially
# growing wait, since a short fixed backoff often isn't enough for a per-minute-style
# limit to actually clear. This matters most during the morning bulk historical fetch
# (fyers_service.FyersDataService.get_candles_bulk), where many symbols are fetched
# back-to-back right after market open.
RATE_LIMIT_MAX_RETRIES = 5
RATE_LIMIT_BACKOFF_BASE_SECONDS = 3  # doubles each attempt: 3s, 6s, 12s, 24s, 48s

# Fyers caps API calls per second per account/plan (you mentioned 9/sec for
# yours). Every single call FyersDataService makes - quotes, history,
# retries included - goes through fyers_service.RateLimiter using this
# value. Set it a little under your actual documented limit, not exactly at
# it, to leave headroom for clock jitter and any other process sharing the
# same API key (e.g. a separate WebSocket connection).
FYERS_MAX_CALLS_PER_SECOND = 8

# How many symbols to pack into a single batched /quotes call. Fyers caps
# how many comma-separated symbols one quotes request accepts - verify the
# current limit for your plan in the API docs before changing this.
QUOTES_BATCH_SIZE = 50

# Dry-run: when True (default) the agent only *simulates* trades in memory and
# CSV, and NEVER calls fyers.place_order(). Only flip to False after you have
# paper-traded the logic for a good stretch and understand the risk involved
# (see README "Before you go live").
DRY_RUN = True

# Placeholder order size used by SignalEngine._maybe_place_live_order()'s log
# messages and, once you wire in a real order call, its qty= parameter. This
# project has never done capital-based position sizing (see
# backtest_strategy_picks.py for that, in a different tool) - replace this
# with real sizing logic before DRY_RUN = False means anything.
DEFAULT_ORDER_QTY = 1

# Tick-level stop-loss/target/trailing-stop (STOP_LOSS_PCT/TARGET_PCT/TRAILING_SL_PCT)
# has been removed. Stop-loss is now purely candle/VWAP-driven: see
# CONSECUTIVE_CANDLES_FOR_STOPLOSS above and signal_engine.py's module docstring - the
# ONLY way a position closes before EOD is 2 consecutive 5-min candles confirming the
# move against it, the same conviction bar as entry, in both directions.
