"""
global_sentiment.py
--------------------
A lightweight, *directional* read on whether global markets look bullish or
bearish ahead of the Indian session, plus an optional LLM-assisted layer for
qualitative macro / geopolitical sentiment (the "customised agent" piece).

This module is informational only - it does NOT gate or trigger anything in
signal_engine.py. Print it, log it, glance at it over coffee; treat it as a
dashboard, not a green/red trading light.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta

import yfinance as yf

logger = logging.getLogger("orb_agent.sentiment")

# Tickers used as global-cue proxies. GIFT Nifty itself isn't reliably
# available on yfinance, so this uses the standard proxy set traders watch
# before the Indian open: US overnight action, Asian majors, crude, dollar
# index and the VIX.
GLOBAL_TICKERS = {
    "S&P 500": "^GSPC",
    "Nasdaq": "^IXIC",
    "Dow Jones": "^DJI",
    "Nikkei 225": "^N225",
    "Hang Seng": "^HSI",
    "US VIX": "^VIX",
    "Crude Oil (WTI)": "CL=F",
    "Dollar Index": "DX-Y.NYB",
}

# Rule-of-thumb weights: positive equity moves lean bullish for India
# (risk-on), while VIX / crude / dollar strength lean bearish (fear,
# import-cost pressure, and FII outflow pressure respectively).
SENTIMENT_WEIGHTS = {
    "S&P 500": 1.0, "Nasdaq": 0.5, "Dow Jones": 0.5,
    "Nikkei 225": 0.5, "Hang Seng": 0.5,
    "US VIX": -1.0, "Crude Oil (WTI)": -0.5, "Dollar Index": -0.5,
}

# A SEPARATE proxy set for MCX commodity sentiment (used by
# bootstrap.decide_todays_commodity_direction(), NOT by the equity/options
# decide_todays_direction() above) - MCX commodities trade against global
# COMMODITY prices, not global equity indices, so reusing GLOBAL_TICKERS'
# S&P500/Nasdaq/VIX-style equity-cue read for commodities would be scoring
# the wrong market. Covers the same underlyings MCX_COMMODITY_UNIVERSE
# trades (gold, silver, crude, copper, natural gas) plus the dollar index,
# which commodity prices (quoted in USD globally) move inversely against.
COMMODITY_GLOBAL_TICKERS = {
    "Gold": "GC=F",
    "Silver": "SI=F",
    "Crude Oil (WTI)": "CL=F",
    "Brent Crude": "BZ=F",
    "Natural Gas": "NG=F",
    "Copper": "HG=F",
    "Dollar Index": "DX-Y.NYB",
}

# Rule-of-thumb weights: each commodity's own global (USD) price move is the
# direct, dominant driver of its MCX (INR) contract, so those get a strong
# positive weight. Dollar Index strength typically correlates with WEAKER
# USD-denominated commodity prices (the classic inverse dollar-commodity
# relationship) - note this is a simplification: a stronger dollar also
# makes imports costlier in INR terms, a partially offsetting effect this
# simple linear score doesn't attempt to model. Treat the output the same
# way score_global_bias()'s docstring already does: a talking point, not a
# signal to act on by itself.
COMMODITY_SENTIMENT_WEIGHTS = {
    "Gold": 1.0, "Silver": 1.0,
    "Crude Oil (WTI)": 1.0, "Brent Crude": 0.5,
    "Natural Gas": 0.5, "Copper": 0.5,
    "Dollar Index": -0.75,
}


def _fetch_live_snapshot(tickers: dict[str, str]) -> dict[str, float]:
    """Shared body for fetch_global_snapshot()/fetch_commodity_global_snapshot() - returns
    {name: % change over the last completed session} for each ticker in `tickers`."""
    snapshot = {}
    for name, ticker in tickers.items():
        try:
            hist = yf.Ticker(ticker).history(period="5d", interval="1d")
            if len(hist) < 2:
                continue
            prev_close, last_close = hist["Close"].iloc[-2], hist["Close"].iloc[-1]
            pct_change = (last_close - prev_close) / prev_close * 100
            snapshot[name] = round(float(pct_change), 2)
        except Exception as exc:
            logger.warning("Could not fetch global sentiment ticker %s (%s): %s", name, ticker, exc)
    return snapshot


def fetch_global_snapshot() -> dict[str, float]:
    """Returns {name: % change over the last completed session} for each ticker in
    GLOBAL_TICKERS (the equity-cue set - see decide_todays_direction())."""
    return _fetch_live_snapshot(GLOBAL_TICKERS)


def fetch_commodity_global_snapshot() -> dict[str, float]:
    """Same mechanics as fetch_global_snapshot(), over COMMODITY_GLOBAL_TICKERS (the
    gold/silver/crude/copper/natural-gas/dollar-index set) instead - used by
    bootstrap.decide_todays_commodity_direction() so MCX commodities get a direction
    derived from global COMMODITY prices, not global equity indices."""
    return _fetch_live_snapshot(COMMODITY_GLOBAL_TICKERS)


def _fetch_snapshot_as_of(tickers: dict[str, str], as_of_date: date) -> dict[str, float]:
    """Shared body for fetch_global_snapshot_as_of()/fetch_commodity_global_snapshot_as_of().

    The % change between the last two COMPLETE trading sessions strictly before
    as_of_date - i.e. what a trader's pre-market read would have shown on the morning of
    as_of_date, using only data that existed by then.

    Note the deliberate `end=as_of_date` (exclusive of as_of_date itself in yfinance's
    convention) - this must never include as_of_date's own session, or the "sentiment"
    would be computed using data that wasn't yet available before that day's Indian
    market open, silently leaking future information into a backtest.
    """
    snapshot = {}
    start = (as_of_date - timedelta(days=15)).strftime("%Y-%m-%d")
    end = as_of_date.strftime("%Y-%m-%d")
    for name, ticker in tickers.items():
        try:
            hist = yf.Ticker(ticker).history(start=start, end=end, interval="1d")
            if len(hist) < 2:
                continue
            prev_close, last_close = hist["Close"].iloc[-2], hist["Close"].iloc[-1]
            pct_change = (last_close - prev_close) / prev_close * 100
            snapshot[name] = round(float(pct_change), 2)
        except Exception as exc:
            logger.warning("Could not fetch historical sentiment ticker %s (%s) as of %s: %s",
                            name, ticker, as_of_date, exc)
    return snapshot


def fetch_global_snapshot_as_of(as_of_date: date) -> dict[str, float]:
    """
    Historical counterpart to fetch_global_snapshot(): see _fetch_snapshot_as_of()'s
    docstring for the exact "only data available by then" contract. Used by backtest.py
    (via bootstrap.decide_direction_for_date) to compute what direction would ACTUALLY
    have been chosen each day of a historical backtest, rather than replaying one fixed
    direction across the whole range.
    """
    return _fetch_snapshot_as_of(GLOBAL_TICKERS, as_of_date)


def fetch_commodity_global_snapshot_as_of(as_of_date: date) -> dict[str, float]:
    """Historical counterpart to fetch_commodity_global_snapshot(), over
    COMMODITY_GLOBAL_TICKERS - see _fetch_snapshot_as_of()'s docstring."""
    return _fetch_snapshot_as_of(COMMODITY_GLOBAL_TICKERS, as_of_date)


def _score_bias(snapshot: dict[str, float], weights: dict[str, float]) -> tuple[str, float]:
    """Shared body for score_global_bias()/score_commodity_global_bias() - combines a
    snapshot into a single heuristic score and label using the given {name: weight} map.
    This is a rule-of-thumb, not a fitted model - treat the output as a talking point /
    conversation starter, not a signal to act on."""
    score = sum(snapshot.get(name, 0.0) * weight for name, weight in weights.items())
    if score > 0.5:
        label = "BULLISH"
    elif score < -0.5:
        label = "BEARISH"
    else:
        label = "NEUTRAL"
    return label, round(score, 2)


def score_global_bias(snapshot: dict[str, float]) -> tuple[str, float]:
    """Scores a fetch_global_snapshot() result using SENTIMENT_WEIGHTS (the equity-cue
    weights) - see _score_bias()'s docstring."""
    return _score_bias(snapshot, SENTIMENT_WEIGHTS)


def score_commodity_global_bias(snapshot: dict[str, float]) -> tuple[str, float]:
    """Scores a fetch_commodity_global_snapshot() result using COMMODITY_SENTIMENT_WEIGHTS
    - see _score_bias()'s docstring. Used by bootstrap.decide_todays_commodity_direction()."""
    return _score_bias(snapshot, COMMODITY_SENTIMENT_WEIGHTS)


def get_llm_news_sentiment(headlines: list[str], api_key: str,
                            model: str = "claude-sonnet-4-6") -> str:
    """
    Optional: send a handful of the morning's top macro/geopolitical
    headlines to Claude and ask for a short, structured bullish/bearish/
    neutral read for Indian equities.

    Requires: pip install anthropic, and an Anthropic API key in
    config.ANTHROPIC_API_KEY (or passed in directly).

    Why bother with this alongside score_global_bias()? Price-based scoring
    can tell you markets moved; it can't tell you *why*, or whether a
    geopolitical headline is likely to matter tomorrow. An LLM call is the
    piece that reasons over qualitative news the way a human trader would -
    it's the natural place to plug in "geopolitical sentiment" from the
    original brief, which isn't really a numeric time series at all.
    """
    import anthropic

    client = anthropic.Anthropic(api_key=api_key)
    prompt = (
        "You are helping a discretionary Indian equity trader form a pre-market view. "
        "Given these overnight headlines, respond with exactly one line in the format "
        "'BIAS: <BULLISH|BEARISH|NEUTRAL> | REASON: <one sentence>'.\n\nHeadlines:\n"
        + "\n".join(f"- {h}" for h in headlines)
    )
    response = client.messages.create(
        model=model,
        max_tokens=100,
        messages=[{"role": "user", "content": prompt}],
    )
    return response.content[0].text.strip()


# ----------------------------------------------------------------------------
# NEW API: combined news + EMA bias for a single stock or index.
# ----------------------------------------------------------------------------
def fyers_symbol_to_yahoo(fyers_symbol: str) -> str:
    """
    Converts a Fyers equity symbol ('NSE:TCS-EQ') to yfinance's convention
    ('TCS.NS'), so get_stock_news_ema_bias() below can be called directly
    with symbols from elsewhere in this codebase (e.g. a future per-stock
    use against the opening-range shortlist). Only handles the common
    NSE:<SYMBOL>-EQ pattern - anything else (an index symbol, a BSE symbol,
    ...) is returned unchanged, so check the result if you pass something
    unusual.
    """
    if fyers_symbol.startswith("NSE:") and fyers_symbol.endswith("-EQ"):
        core = fyers_symbol[len("NSE:"):-len("-EQ")]
        return f"{core}.NS"
    return fyers_symbol


def _compute_ema_bias(yahoo_symbol: str, ema_fast_period: int, ema_slow_period: int) -> tuple[str, dict]:
    """
    Classic EMA-crossover technical read: BULLISH if the fast EMA is above
    the slow EMA AND price is above the fast EMA (confirmed uptrend);
    BEARISH for the mirror image; NEUTRAL otherwise (e.g. mixed signals
    around a crossover); UNKNOWN if there isn't enough price history.
    """
    try:
        hist = yf.Ticker(yahoo_symbol).history(period="6mo", interval="1d")
        if len(hist) < ema_slow_period + 1:
            logger.warning("Not enough price history for %s (%d bars) to compute "
                            "EMA(%d) reliably.", yahoo_symbol, len(hist), ema_slow_period)
            return "UNKNOWN", {}

        close = hist["Close"]
        ema_fast = close.ewm(span=ema_fast_period, adjust=False).mean()
        ema_slow = close.ewm(span=ema_slow_period, adjust=False).mean()
        latest_close = float(close.iloc[-1])
        latest_fast = float(ema_fast.iloc[-1])
        latest_slow = float(ema_slow.iloc[-1])

        if latest_fast > latest_slow and latest_close > latest_fast:
            bias = "BULLISH"
        elif latest_fast < latest_slow and latest_close < latest_fast:
            bias = "BEARISH"
        else:
            bias = "NEUTRAL"

        detail = {
            "latest_close": round(latest_close, 2),
            f"ema_{ema_fast_period}": round(latest_fast, 2),
            f"ema_{ema_slow_period}": round(latest_slow, 2),
        }
        return bias, detail
    except Exception as exc:
        logger.warning("Could not compute EMA bias for %s: %s", yahoo_symbol, exc)
        return "UNKNOWN", {}


def _fetch_recent_headlines(yahoo_symbol: str, count: int) -> list[str]:
    """
    yfinance's `.news` schema has shifted between versions (sometimes a
    flat 'title' key, sometimes nested under 'content') and can return an
    empty list even when there genuinely is recent news - this checks both
    shapes and never raises, since a missing headline shouldn't take down
    the EMA half of the read.
    """
    try:
        news_items = yf.Ticker(yahoo_symbol).news or []
        headlines = []
        for item in news_items[:count]:
            title = item.get("title") or item.get("content", {}).get("title")
            if title:
                headlines.append(title)
        return headlines
    except Exception as exc:
        logger.warning("Could not fetch news for %s: %s", yahoo_symbol, exc)
        return []


def get_stock_news_ema_bias(
    yahoo_symbol: str,
    anthropic_api_key: str = "",
    ema_fast_period: int = 12,
    ema_slow_period: int = 26,
    news_headline_count: int = 5,
    model: str = "claude-sonnet-4-6",
) -> dict:
    """
    Combines a price-based EMA(fast) vs EMA(slow) technical read with an
    LLM-scored read of that symbol's own recent news headlines (fetched via
    yfinance) into one bullish/bearish/neutral verdict.

    yahoo_symbol: a Yahoo Finance ticker - "^NSEI" for Nifty 50, or
        "TCS.NS" for an NSE-listed stock. NOT the same as a Fyers symbol
        ("NSE:TCS-EQ") used elsewhere in this codebase - convert with
        fyers_symbol_to_yahoo() first if that's what you have.

    Without anthropic_api_key, the news half is skipped (news_bias stays
    None) and combined_bias falls back to the EMA-only read - this function
    still works, just without the qualitative layer.

    Returns:
        {
            "yahoo_symbol": str,
            "ema_bias": "BULLISH" | "BEARISH" | "NEUTRAL" | "UNKNOWN",
            "ema_detail": {"latest_close": ..., "ema_<fast>": ..., "ema_<slow>": ...},
            "news_bias": "BULLISH" | "BEARISH" | "NEUTRAL" | None,
            "news_reason": str | None,
            "headlines_used": [str, ...],
            "combined_bias": "BULLISH" | "BEARISH" | "MIXED" | "NEUTRAL" | "UNKNOWN",
        }
    "MIXED" means the two components actively disagreed (one bullish, one
    bearish) - worth a second look rather than trading through it blindly.
    """
    ema_bias, ema_detail = _compute_ema_bias(yahoo_symbol, ema_fast_period, ema_slow_period)
    headlines = _fetch_recent_headlines(yahoo_symbol, news_headline_count)

    news_bias, news_reason = None, None
    if headlines and anthropic_api_key:
        try:
            raw = get_llm_news_sentiment(headlines, anthropic_api_key, model=model)
            if "BIAS:" in raw:
                head, _, tail = raw.partition("|")
                news_bias = head.split("BIAS:", 1)[1].strip().upper()
                if "REASON:" in tail:
                    news_reason = tail.split("REASON:", 1)[1].strip()
        except Exception as exc:
            logger.warning("Could not get LLM news sentiment for %s: %s", yahoo_symbol, exc)

    if ema_bias in ("BULLISH", "BEARISH") and news_bias in ("BULLISH", "BEARISH"):
        combined_bias = ema_bias if ema_bias == news_bias else "MIXED"
    elif news_bias in ("BULLISH", "BEARISH", "NEUTRAL"):
        combined_bias = news_bias
    else:
        combined_bias = ema_bias  # EMA-only fallback (itself possibly UNKNOWN/NEUTRAL)

    return {
        "yahoo_symbol": yahoo_symbol,
        "ema_bias": ema_bias, "ema_detail": ema_detail,
        "news_bias": news_bias, "news_reason": news_reason,
        "headlines_used": headlines,
        "combined_bias": combined_bias,
    }
